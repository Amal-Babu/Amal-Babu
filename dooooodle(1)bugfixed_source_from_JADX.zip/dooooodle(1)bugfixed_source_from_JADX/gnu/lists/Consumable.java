package gnu.lists;

public interface Consumable {
    void consume(Consumer consumer);
}
