package gnu.lists;

public interface ItemPredicate {
    boolean isInstancePos(AbstractSequence abstractSequence, int i);
}
