package com.google.appinventor.components.runtime.errors;

interface package-info {
}
