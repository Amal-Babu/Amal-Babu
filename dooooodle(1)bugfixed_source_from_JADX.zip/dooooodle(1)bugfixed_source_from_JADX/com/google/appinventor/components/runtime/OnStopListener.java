package com.google.appinventor.components.runtime;

public interface OnStopListener {
    void onStop();
}
