package com.google.appinventor.components.runtime;

interface package-info {
}
