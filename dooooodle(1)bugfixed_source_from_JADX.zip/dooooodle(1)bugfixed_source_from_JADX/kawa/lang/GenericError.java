package kawa.lang;

public class GenericError extends RuntimeException {
    public GenericError(String message) {
        super(message);
    }
}
